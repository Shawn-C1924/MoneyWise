# MoneyWise showcase

The MoneyWise visual identity uses a dark-green finance theme, gold coin stacks, and an upward growth arrow.

The public project does not include personal financial figures or screenshots containing private budgeting information.
